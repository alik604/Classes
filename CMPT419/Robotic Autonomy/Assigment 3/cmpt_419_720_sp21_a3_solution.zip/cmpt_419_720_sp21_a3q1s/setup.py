# setup.py
from setuptools import setup

setup(
    name='cmpt720a3q1code',
    version='0.1.0',
    packages=['cmpt720a3q1code'],
)