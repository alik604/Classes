#!/usr/bin/env python

import rospy
from nav_msgs.msg import Odometry
from nuslam.msg import TurtleMap
from geometry_msgs.msg import Pose2D
from geometry_msgs.msg import TransformStamped
# from geometry_msgs.msg import Quaternion
# from tf2_ros import transform_broadcaster
# from tf.transformations import quaternion_from_euler, euler_from_quaternion
from rigid2d.srv import SetPose, SetPoseResponse
import math
import numpy as np
import tf_conversions
import tf2_ros

class Vector2D:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.norm_x = 0
        self.norm_y = 0

    def set_fields(self, x, y):
        self.x = x
        self.y = y
        self.norm_x = 0
        self.norm_y = 0

    def length(self, v):
        return math.sqrt(pow(v.x, 2) + pow(v.y, 2))

    def angle(self, v):
        return math.atan(v.y / v.x)

    def distance(self, v1, v2):
        return math.sqrt(pow(v1.x - v2.x, 2) + pow(v1.y - v2.y, 2))

    def normalize(self):
        if self.x != 0:
            self.norm_x = self.x / math.sqrt(pow(self.x, 2) + pow(self.y, 2))
        else:
            self.norm_x = 0
        if self.y != 0:
            self.norm_y = self.y / math.sqrt(pow(self.x, 2) + pow(self.y, 2))
        else:
            self.norm_y = 0


class Utils:
    def __init__(self):
        pass

    # \brief wraps an angle between +- PI
    # \param rad - angle in radians
    # \returns the wrapped angle in radians
    def normalize_angle(self, rad):
        lim = math.floor((rad + math.pi) / (2.0 * math.pi))
        rad = rad + math.pi - lim * 2.0 * math.pi
        if rad < 0:
            rad += 2.0 * math.pi

        rad -= math.pi
        return rad

    def almost_zero(self, a):
        if math.fabs(a - 0.0000000000) < 1.0e-10:
            return True
        else:
            return False

    def cartesianToPolar(self, pose):
        rb = RangeBear()
        range = math.sqrt(pow(pose.x, 2) + pow(pose.y, 2))
        bear = self.normalize_angle(math.atan2(pose.y, pose.x))
        rb.set_fields(range, bear)
        return rb


class Point2D:
    def __init__(self, x, y):
        self.x = x
        self.y = y


class RangeBear:
    def __init__(self):
        self.range = 0
        self.bearing = 0

    def set_fields(self, r, b):
        self.range = r
        self.bearing = b


class Point:
    def __init__(self):
        self.range_bear = RangeBear()
        self.pose = Vector2D()

        self.init = False  # new or old landmark
        self.index = 0  # index in landmark list
        self.seen_count = 0  # criterian for adding to map state

    def set_pose(self, pose):
        self.pose = pose
        self.range_bear = self.cartesianToPolar(self.pose)

        self.init = False
        self.index = 0
        self.seen_count = 0

    def normalize_angle(self, rad):
        lim = math.floor((rad + math.pi) / (2.0 * math.pi))
        rad = rad + math.pi - lim * 2.0 * math.pi
        if rad < 0:
            rad += 2.0 * math.pi

        rad -= math.pi
        return rad

    def set_rnage_bear(self, rb):
        self.range_bear = rb
        self.pose = self.polarToCartesian(self.range_bear)

        self.init = False
        self.index = 0
        self.seen_count = 0

    def cartesianToPolar(self, pose):
        range = math.sqrt(pow(pose.x, 2) + pow(pose.y, 2))
        bear = self.normalize_angle(math.atan2(pose.y, pose.x))
        rb = RangeBear()
        rb.set_fields(range, bear)
        return rb

    def polarToCartesian(self, rb):
        pose = Vector2D()
        x = rb.range * math.cos(rb.bearing)
        y = rb.range * math.sin(rb.bearing)
        pose.set_fields(x, y)
        return pose


class Transform2DS:
    def __init__(self):
        self.theta = 0
        self.x = 0
        self.y = 0

    def set_fields(self, theta, x, y):
        self.theta = theta
        self.x = x
        self.y = y


class Twist2D:
    def __init__(self):
        # linear and angular components
        self.v_x_ = 0
        self.v_y_ = 0
        self.w_z_ = 0

    def set_fields(self, w_z, v_x, v_y):
        # linear and angular components
        self.v_x_ = v_x
        self.v_y_ = v_y
        self.w_z_ = w_z

    def convert(self, tf):
        tw_s = Twist2D()
        tw_s.set_fields(self.w_z_, (self.v_x_ * tf.ctheta - self.v_y_ * tf.stheta + self.w_z_ * tf.y)
                        , (self.v_y_ * tf.ctheta + self.v_x_ * tf.stheta - self.w_z_ * tf.x))

        if math.fabs(tw_s.v_x_ - 1e-6) < 0:
            tw_s.v_x_ = 0
        if math.fabs(tw_s.v_y_ - 1e-6) < 0:
            tw_s.v_y_ = 0
        if math.fabs(tw_s.w_z_ - 1e-6) < 0:
            tw_s.w_z_ = 0

    def reassing(self, w_z, v_x, v_y):
        self.v_x_ = v_x
        self.v_y_ = v_y
        self.w_z_ = w_z


class Transform2D:
    def __init__(self):
        self.theta = 0
        self.ctheta = math.cos(self.theta)
        self.stheta = math.sin(self.theta)
        self.x = 0
        self.y = 0

    def set_rad(self, rad):
        self.theta = rad
        self.ctheta = math.cos(self.theta)
        self.stheta = math.sin(self.theta)
        self.x = 0
        self.y = 0

    def set_v_rad(self, v, rad):
        self.theta = rad
        self.ctheta = math.cos(self.theta)
        self.stheta = math.sin(self.theta)
        self.x = v.x
        self.y = v.y

    def set_fields(self, theta, ctheta, stheta, x, y):
        self.theta = theta
        self.ctheta = ctheta
        self.stheta = stheta
        self.x = x
        self.y = y

    def inv(self):
        temp2d = Transform2D()
        temp2d.set_fields(self.theta, self.ctheta, self.stheta, self.x, self.y)

        temp2d.stheta = -temp2d.stheta
        temp2d.theta = math.atan2(temp2d.stheta, temp2d.ctheta)
        temp2d.ctheta = math.cos(temp2d.theta)

        temp2d.x = -(temp2d.ctheta * self.x - temp2d.stheta * self.y)
        temp2d.y = -(temp2d.stheta * self.x + temp2d.ctheta * self.y)

        if math.fabs(temp2d.x - 0.0000000000) < 1.0e-10:
            temp2d.x = 0.0
        if math.fabs(temp2d.y - 0.0000000000) < 1.0e-10:
            temp2d.y = 0.0
        if math.fabs(temp2d.theta - 0.0000000000) < 1.0e-10:
            temp2d.theta = 0.0
            temp2d.stheta = math.sin(temp2d.theta)
            temp2d.ctheta = math.cos(temp2d.theta)

        return temp2d

    def mult(self, rhs):
        res = Transform2D()
        res.set_fields(self.theta, self.ctheta, self.stheta, self.x, self.y)
        res.x = res.ctheta * rhs.x - res.stheta * rhs.y + res.x
        res.y = res.stheta * rhs.x + res.ctheta * rhs.y + res.y
        res.theta = res.theta + rhs.theta
        res.ctheta = math.cos(res.theta)
        res.stheta = math.sin(res.theta)

        if math.fabs(res.x - 0.0000000000) < 1.0e-10:
            res.x = 0.0

        if math.fabs(res.y - 0.0000000000) < 1.0e-10:
            res.y = 0.0

        if math.fabs(res.theta - 0.0000000000) < 1.0e-10:
            res.theta = 0.0
            res.ctheta = math.cos(res.theta)
            res.stheta = math.sin(res.theta)

        return res

    def integerateTwist(self, twist):
        pass

    def displacement(self):
        temp = Transform2DS()
        temp.set_fields(self.theta, self.x, self.y)
        return temp

class Slam:
    def __init__(self):
        # define variables in slam.cpp main function
        self.max_range_ = 2.0
        self.x_noise = 1e-6
        self.y_noise = 1e-6
        self.theta_noise = 1e-3
        self.range_noise = 1e-8
        self.bearing_noise = 1e-10
        self.mahalanobis_lower = 100.0
        self.mahalanobis_upper = 1e5

        # odom_fid_ (string): parent frame ID for the published tf transform
        # body_fid_ (string): child frame ID for the published tf transform
        # landmark_fid_ (string): for landmark frame id publishing
        self.odom_fid_ = "second_map"
        self.body_fid_ = "odom"
        self.landmark_fid_ = "base_scan"
        self.frame_id_ = "second_map"

        # odom_tf (geometry_msgs::TransformStamped): odometry frame transform used to update RViz sim
        # odom (nav_msgs::Odometry): odometry message containing pose and twist published to odom topic
        self.odom_broadcaster_ = tf2_ros.TransformBroadcaster()

        # define service
        rospy.Service("set_pose", SetPose, self.set_poseCallback)
        self.reset_pose_ = Pose2D()  # will be used in service

        # define publishers
        self.odom_publisher = rospy.Publisher("python/ekf/odom", Odometry, queue_size=1)
        self.lm_publisher = rospy.Publisher("slam/landmarks", TurtleMap, queue_size=1)
        # publishing map_state (land marks)
        self.radii = []
        self.x_pts = []
        self.y_pts = []

        # define subscribers and their flags and variables
        self.callback_flag = False  # specifies whether to send a new transform (only when new pose is read)
        self.odom_flag = False  # specifies whether a new joint position was recorded (used in EKF Prediction)
        self.landmark_flag = False  # specifies whether a new landmark position was recorded (used in EKF Update)
        self.service_flag = False
        rospy.Subscriber("odom", Odometry, self.odom_callback)  # Based on piazza
        rospy.Subscriber("landmarks_node/landmarks", TurtleMap, self.landmark_callback)
        self.twist2d = Twist2D()  # get twist from odom topic
        self.odom_pose = Pose2D()  # get robot pose from odom topic

        # Initialize EKF class with robot state, vector of 12 landmarks at 0,0,0, and noise
        map_state = []
        for i in range(12):
            map_state.append(Point())
        xyt_noise = Pose2D(self.x_noise, self.y_noise, self.theta_noise)
        rb_noise = RangeBear()
        rb_noise.set_fields(self.range_noise, self.bearing_noise)
        self.ekf = EKF(map_state, xyt_noise, rb_noise, self.max_range_, self.mahalanobis_lower, self.mahalanobis_upper)

        self.frequency = 60.0
        rospy.spin()  # TODO is spinOnce in cpp, may lead to problem

    def main(self):

        #print("main executing")
        # NOTE: All callbacks will be executed before rest of main
        # so if both odom and landmark update are available, both will
        # execute before rest of main loop. Order cannot be guaranteed however

        current_time = rospy.Time.now()

        # TODO: complete the service
        if self.service_flag:
            self.ekf.reset_pose(self.reset_pose_)
            self.service_flag = False

        if self.callback_flag:
            # SLAM Node publishes Tmo = map->odom
            # To get this, we do Tmo = Tmb * Tob.inv
            # Where Tmb = map->base and Tob = odom->base
            ekf_pose = self.ekf.return_pose()

            # Construct Tmb
            Vmb = Vector2D()
            Vmb.set_fields(ekf_pose.x, ekf_pose.y)
            Tmb = Transform2D()
            Tmb.set_v_rad(Vmb, ekf_pose.theta)

            # Construct Tob
            Vob = Vector2D()
            Vob.set_fields(self.odom_pose.x, self.odom_pose.y)
            Tob = Transform2D()
            Tob.set_v_rad(Vob, self.odom_pose.theta)

            temp = Tob.inv()

            Tmo = Tmb.mult(temp)
            # print("Tmb  %f - Tob   %f -  Tob_inv  %f - Tmo %f", Tmb.theta, Tob.theta, temp.theta, Tmo.theta)

            TmoS = Tmo.displacement()

            odom_tf = TransformStamped()
            odom_tf.header.stamp = current_time
            odom_tf.header.frame_id = self.odom_fid_
            odom_tf.child_frame_id = self.body_fid_
            odom_tf.transform.translation.x = TmoS.x
            odom_tf.transform.translation.y = TmoS.y
            odom_tf.transform.translation.z = 0

            # TODO possible error
            q = tf_conversions.transformations.quaternion_from_euler(0, 0, TmoS.theta)
            odom_tf.transform.rotation.x = q[0]
            odom_tf.transform.rotation.y = q[1]
            odom_tf.transform.rotation.z = q[2]
            odom_tf.transform.rotation.w = q[3]
            self.odom_broadcaster_.sendTransform(odom_tf)

            # update and publish odometry message
            odom = Odometry()
            odom.header.stamp = current_time
            odom.header.frame_id = self.odom_fid_

            odom.pose.pose.position.x = ekf_pose.x
            odom.pose.pose.position.y = ekf_pose.y
            odom.pose.pose.position.z = 0.0
            odom.pose.pose.orientation.x = q[0]
            odom.pose.pose.orientation.y = q[1]
            odom.pose.pose.orientation.z = q[2]
            odom.pose.pose.orientation.w = q[3]

            odom.child_frame_id = self.body_fid_
            odom.twist.twist.linear.x = self.twist2d.v_x_
            odom.twist.twist.linear.y = self.twist2d.v_y_
            odom.twist.twist.angular.z = self.twist2d.w_z_

            self.odom_publisher.publish(odom)
            self.callback_flag = False

            if self.landmark_flag:
                belief_map = TurtleMap()
                belief_map.radii = self.radii
                belief_map.x_pts = self.x_pts
                belief_map.y_pts = self.y_pts
                belief_map.header.stamp = rospy.Time.now()
                belief_map.header.frame_id = self.frame_id_
                self.lm_publisher.publish(belief_map)
                self.landmark_flag = False

            # TODO sleep rate

    def normalize_angle(self, rad):
        lim = math.floor((rad + math.pi) / (2.0 * math.pi))
        rad = rad + math.pi - lim * 2.0 * math.pi
        if rad < 0:
            rad += 2.0 * math.pi

        rad -= math.pi
        return rad

    def odom_callback(self, odometry):

        self.twist2d.v_x_ = odometry.twist.twist.linear.x * 10  # Found this *10 by debugging!
        self.twist2d.v_y_ = odometry.twist.twist.linear.y * 10
        self.twist2d.w_z_ = odometry.twist.twist.angular.z * 10
        # rospy.loginfo("odom twist2d: %f   %f   %f", self.twist2d.v_x_, self.twist2d.v_y_, self.twist2d.w_z_)

        self.odom_pose.x = odometry.pose.pose.position.x
        self.odom_pose.y = odometry.pose.pose.position.y
        self.odom_pose.theta = math.atan2((2.0 * (
                odometry.pose.pose.orientation.w * odometry.pose.pose.orientation.z + odometry.pose.pose.orientation.x * odometry.pose.pose.orientation.y)),
                                          (1.0 - 2.0 * (
                                                  odometry.pose.pose.orientation.y * odometry.pose.pose.orientation.y + odometry.pose.pose.orientation.z * odometry.pose.pose.orientation.z)))
        self.odom_pose.theta = self.normalize_angle(self.odom_pose.theta)
        # rospy.loginfo("Odom pose: %f    %f   %f", self.odom_pose.x, self.odom_pose.y, self.odom_pose.theta)

        self.odom_flag = True
        self.callback_flag = True

    def landmark_callback(self, map):
        # rospy.loginfo("land mark is being subscribed")

        # Convert map to vector of Points
        # Map data has x,y relative to robot, so no change needed
        measurements = []
        for i in range(len(map.radii)):
            map_pose = Vector2D()
            map_pose.set_fields(map.x_pts[i], map.y_pts[i])
            map_point = Point()
            map_point.set_pose(map_pose)
            measurements.append(map_point)
            # rospy.loginfo("landmarks: %f    %f   %f    %f", map_point.pose.x, map_point.pose.x,
            #             map_point.range_bear.range, map_point.range_bear.bearing)
        if self.odom_flag:
            # perform prediction step
            self.ekf.predict(self.twist2d)
            # perform correction step
            self.ekf.measurement_update(measurements)

        map_state = self.ekf.return_map()  # list of Point
        self.radii = []
        self.x_pts = []
        self.y_pts = []
        for p in map_state:
            self.radii.append(0.08)
            self.x_pts.append(p.pose.x)
            self.y_pts.append(p.pose.y)

        self.landmark_flag = True
        self.odom_flag = False
        self.callback_flag = True

        self.main()  # TODO, am not sure if I placed here correctly, what about Frequency

    def set_poseCallback(self, req):
        res = SetPoseResponse
        self.reset_pose_.x = req.x
        self.reset_pose_.y = req.y
        self.reset_pose_.theta = req.theta
        res.result = True

        self.service_flag = True
        self.callback_flag = True

        return res.result

class EKF:
    def __init__(self, map_state, xyt_noise, rb_noise, max_range,
                 mahalanobis_lower, mahalanobis_upper):
        self.utils = Utils()

        # define the map_state, robot_state and combined state
        self.map_state_ = map_state  # list of Points
        self.robot_state_ = Pose2D(0, 0, 0)
        self.state_ = np.zeros(3 + 2 * len(self.map_state_), dtype=float)

        # define process noise
        self.xyt_noise_var = xyt_noise  # Pose2D
        self.process_noise_Q = self.process_noise(self.xyt_noise_var, len(self.map_state_))
        self.cove_mtx = self.covariance_matrix(len(self.map_state_))

        self.N = 0
        self.mahalanobis_lower = mahalanobis_lower
        self.mahalanobis_upper = mahalanobis_upper

        self.rb_noise_var = rb_noise  # RangeBear
        self.msr_noise_R = self.msr_noise(self.rb_noise_var)

        self.max_range_ = max_range

    def measurement_update(self, measurements):  # list of Points
        for measure in measurements:
            noise_v = np.array([2e-10, 2e-10])  # self.get_multivariate_noise(self.msr_noise_R) TODO
            # rospy.loginfo("landmarks: %f    %f   %f    %f", measure.pose.x, measure.pose.x,
            #              measure.range_bear.range, measure.range_bear.bearing)
            z = np.zeros(2)
            z[0] = measure.range_bear.range + noise_v[0]
            z[1] = measure.range_bear.bearing + noise_v[1]

            z[1] = self.utils.normalize_angle(z[1])

            d_k = self.mahalanobis(z)
            d_star = np.min(d_k)
            d_star_index = np.argmin(d_k)
            # print((d_k))
            if d_star < self.mahalanobis_lower or d_star > self.mahalanobis_upper:

                if d_star < self.mahalanobis_lower:
                    i = d_star_index

                elif d_star > self.mahalanobis_upper:

                    # increament N
                    i = self.N
                    self.N += 1
                    # add new landmark to state
                    if self.N <= len(self.map_state_):
                        self.state_[3 + 2 * i] = measure.pose.x + self.state_[1]
                        self.state_[4 + 2 * i] = measure.pose.y + self.state_[2]

                if self.N <= len(self.map_state_):
                    # Add measurement to state and incorporate into EKF
                    # First, get theoretical expected measurement based on belief in [r,b] format
                    # Pose difference between robot and landmark
                    cartesian_measurement = Vector2D()
                    cartesian_measurement.set_fields(self.state_[3 + 2 * i] - self.state_[1],
                                                     self.state_[4 + 2 * i] - self.state_[2])
                    polar_measurement = self.utils.cartesianToPolar(cartesian_measurement)
                    polar_measurement.bearing = self.utils.normalize_angle(polar_measurement.bearing)
                    # subtract robot heading form polarmeasurements
                    polar_measurement.bearing -= self.state_[0]
                    polar_measurement.bearing = self.utils.normalize_angle(polar_measurement.bearing)
                    z_hat = np.array([polar_measurement.range, polar_measurement.bearing])

                    H = self.inverse_msr_model(i)
                    # Compute the Kalman gain from the linearized measurement model
                    temp1 = np.matmul(self.cove_mtx, np.transpose(H))
                    temp2 = np.matmul(H, self.cove_mtx)
                    temp3 = np.matmul(temp2, np.transpose(H))
                    K = np.matmul(temp1, np.linalg.inv(temp3 + self.msr_noise_R))
                    # K = self.cove_mtx * np.transpose(H) * np.linalg.inv(H * self.cove_mtx * np.transpose(H) + self.msr_noise_R)

                    z_diff = z - z_hat
                    z_diff[1] = self.utils.normalize_angle(z_diff[1])
                    K_update = np.matmul(K, z_diff)
                    self.state_ += K_update
                    self.state_[0] = self.utils.normalize_angle(self.state_[0])
                    self.cove_mtx = np.matmul((np.identity(3 + 2 * len(self.map_state_)) - np.matmul(K, H)),
                                              self.cove_mtx)
                else:
                    self.N = len(self.map_state_)

        # update_robot_state
        self.robot_state_.theta = self.state_[0]
        self.robot_state_.theta = self.utils.normalize_angle(self.robot_state_.theta)
        self.robot_state_.x = self.state_[1]
        self.robot_state_.y = self.state_[2]
        # rospy.loginfo("msr updated: %f   %f    %f", self.state_[1], self.state_[2],self.state_[0])

        # update map_state
        for j in range(len(self.map_state_)):
            self.map_state_[j].pose.x = self.state_[3 + 2 * j]
            self.map_state_[j].pose.y = self.state_[4 + 2 * j]

    def mahalanobis(self, z):
        # steps 10-18 in Probabilistic Robotics, EKFSLAM with Unknown Data Association
        # for k = 0 to k < N (N from 0 to max_num_landmarks) | if N=0, skip
        # First, create a vector of size N to store our mahalanobis distances
        # if N = 0, skip loop and return empty vector, which will indicate that the
        # current measurement is our first landmark, and it will automatically be initialized

        if self.N == 0:
            d_k = np.array([1e12], dtype=float)
        else:
            d_k = np.zeros(self.N, dtype=float)
        # step 10
        for k in range(0, self.N):
            # print("in maha")
            # step 11 to 15
            H = self.inverse_msr_model(k)
            # step 16
            psi = np.matmul(np.matmul(H, self.cove_mtx), np.transpose(H)) + self.msr_noise_R

            # step 17
            cartesian_measurement = Vector2D()
            cartesian_measurement.set_fields(self.state_[3 + 2 * k] - self.state_[1],
                                             self.state_[4 + 2 * k] - self.state_[2])
            polar_measurement = self.utils.cartesianToPolar(cartesian_measurement)
            polar_measurement.bearing = self.utils.normalize_angle(polar_measurement.bearing)

            # subtract robot heading form polarmeasurements
            polar_measurement.bearing -= self.state_[0]
            polar_measurement.bearing = self.utils.normalize_angle(polar_measurement.bearing)

            z_hat = np.array([polar_measurement.range, polar_measurement.bearing], dtype=float)
            z_diff = z - z_hat
            z_diff[1] = self.utils.normalize_angle(z_diff[1])
            d = np.matmul(np.matmul(np.transpose(z_diff), np.linalg.inv(psi)), z_diff)
            d_k[k] = d

        return d_k

    def inverse_msr_model(self, index):
        # based on equation 18, H is constructed of four different matrices
        H = np.zeros((2, 3 + 2 * len(self.map_state_)), dtype=float)

        # calculate distance of the index'th landmark to robot
        x_diff = self.state_[3 + 2 * index] - self.state_[1]  # eq 16
        y_diff = self.state_[4 + 2 * index] - self.state_[2]  # eq 17
        d = pow(x_diff, 2) + pow(y_diff, 2)

        # construct H based on equation 18
        H[0][1] = -x_diff / math.sqrt(d)
        H[0][2] = -y_diff / math.sqrt(d)

        H[1][0] = -1
        H[1][1] = y_diff / d
        H[1][2] = -x_diff / d

        # TODO: maybe leads to problem, index starts from 1 in eq 18
        H[0][3 + 2 * index] = x_diff / math.sqrt(d)
        H[0][4 + 2 * index] = y_diff / math.sqrt(d)
        H[1][3 + 2 * index] = -y_diff / d
        H[1][4 + 2 * index] = x_diff / d

        return H

    def predict(self, twist):
        self.robot_state_.theta = self.utils.normalize_angle(self.robot_state_.theta)
        # noise_w is used in equations 5 and 7 in attached pdf
        # Note that w (called noise_w here) is sampled from a gaussian by mean zero and cov=Q
        noise_w = np.array([1e-4, 1e-4, 1e-4])  # self.get_multivariate_noise(self.process_noise_Q) TODO

        # update the belief (predicted mean) based on equations 5 or 7
        if self.utils.almost_zero(twist.w_z_):
            # equation 5
            belief = Pose2D(self.robot_state_.x + (twist.v_x_ * math.cos(self.robot_state_.theta)) + noise_w[1],
                            self.robot_state_.y + (twist.v_x_ * math.sin(self.robot_state_.theta)) + noise_w[2],
                            self.robot_state_.theta + noise_w[0])
        else:
            # equation 7
            belief = Pose2D(self.robot_state_.x + ((-twist.v_x_ / twist.w_z_) * math.sin(self.robot_state_.theta) + (
                    twist.v_x_ / twist.w_z_) * math.sin(self.robot_state_.theta + twist.w_z_)) + noise_w[1],
                            self.robot_state_.y + ((twist.v_x_ / twist.w_z_) * math.cos(self.robot_state_.theta) + (
                                    -twist.v_x_ / twist.w_z_) * math.cos(
                                self.robot_state_.theta + twist.w_z_)) + noise_w[2],
                            self.robot_state_.theta + twist.w_z_ + noise_w[0])

        belief.theta = self.utils.normalize_angle(belief.theta)

        # Now we have to propagate uncertainty (calculate covariance matrix) based on equation 21
        # for updating covariance we need  matrix A (g matrix in cpp code) and matrix Q
        # Matrix A actually is linearized dynamic model (based on equations 9 and 10)
        A = np.zeros((3 + 2 * len(self.map_state_), 3 + 2 * len(self.map_state_)), dtype=float)
        if self.utils.almost_zero(twist.w_z_):
            A[1][0] = -twist.v_x_ * math.sin(self.robot_state_.theta)
            A[2][0] = twist.v_x_ * math.cos(self.robot_state_.theta)
        else:
            A[1][0] = (-twist.v_x_ / twist.w_z_) * math.cos(self.robot_state_.theta) + (
                    twist.v_x_ / twist.w_z_) * math.cos(
                self.robot_state_.theta + twist.w_z_)
            A[2][0] = (-twist.v_x_ / twist.w_z_) * math.sin(self.robot_state_.theta) + (
                    twist.v_x_ / twist.w_z_) * math.sin(
                self.robot_state_.theta + twist.w_z_)

        A = np.identity((3 + 2 * len(self.map_state_)), dtype=float) + A

        # equation 21
        self.cove_mtx = np.matmul(np.matmul(A, self.cove_mtx), np.transpose(A)) + self.process_noise_Q

        self.robot_state_ = belief
        # rospy.loginfo("robot beliefe: %f   %f    %f", self.robot_state_.x, self.robot_state_.y, self.robot_state_.theta)
        self.state_[0] = self.robot_state_.theta
        self.state_[1] = self.robot_state_.x
        self.state_[2] = self.robot_state_.y

    def process_noise(self, xyt_noise_var, map_size):
        # no noise components for landmarks, because we know they are stationary
        q = np.zeros((2 * map_size + 3, 2 * map_size + 3), dtype=float)
        q[0][0] = xyt_noise_var.theta
        q[1][1] = xyt_noise_var.x
        q[2][2] = xyt_noise_var.y
        return q

    def covariance_matrix(self, map_size):
        covariance = np.zeros((2 * map_size + 3, 2 * map_size + 3), dtype=float)
        # robot covariance is initialized to zero (indicating we are certain about robots pose at the beginning)
        # bottom right's is a diagonal by high covariance meaning we are uncertain about landmarks at the beginning
        for i in range(3, 2 * map_size + 3):
            covariance[i][i] = 1000.0
        return covariance

    def msr_noise(self, rb_noise_var):
        r = np.zeros((2, 2), dtype=float)
        r[0][0] = rb_noise_var.range
        r[1][1] = rb_noise_var.bearing
        return r

    def get_multivariate_noise(self, q):
        L = np.linalg.cholesky(q)
        mrv = np.random.normal(len(q))
        return L * mrv
        return np.identity

    def return_map(self):
        return self.map_state_

    def return_pose(self):
        return self.robot_state_

    def reset_pose(self, pose):
        self.robot_state_ = pose


if __name__ == "__main__":
    rospy.init_node('python_ekf', anonymous=True)
    slam = Slam()
