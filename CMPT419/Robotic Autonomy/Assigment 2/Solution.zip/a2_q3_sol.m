% This file has been modified from the multiple shooting exmaple in the Casadi 
% toolbox

import casadi.*

T = 5; % Time horizon
N = 50; % number of control intervals

%% Declare model variables
x = SX.sym('x');
v = SX.sym('v');
theta = SX.sym('theta');
omega = SX.sym('omega');

state = [x; v; theta; omega];
u = SX.sym('u');

% Problem parameters
M = 0.5;
m = 0.2;
b = 0.1;
l = 0.3;
I = 0.006;
g = 9.81;
uMax = 0.2;

%% Dynamics and cost
% Write \dot v and \dot\omega as the solution of a linear system of
% equations
xdot24 = [M+m            m*l*cos(theta); 
          m*l*cos(theta) I+m*l^2]        \ ...
         [-b*v + m*l*omega^2*sin(theta) + u; 
          -m*g*l*sin(theta)];

xdot = [v; xdot24(1); omega; xdot24(2)];

% Running cost
Jt = u^2;

%% Forward Euler integration
dt = T/N;

f = Function('f', {state, u}, {xdot, Jt}); % f has two inputs and two outputs

X0 = MX.sym('X0', 4);
U = MX.sym('U');

[Xdot, Jk] = f(X0, U);
X = X0 + dt*Xdot;
Q = Jk*dt;

% F has two inputs and two outputs, with the corresponding names
F = Function('F', {X0, U}, {X, Q}, {'x0','p'}, {'xf', 'qf'});

% Evaluate at a test point
Fk = F('x0',[0; 0; pi; 0],'p',1);
disp(Fk.xf)
disp(Fk.qf)

%% Construct the NLP
% Start with an empty NLP
w={};
w0 = [];
lbw = [];
ubw = [];
J = 0;
g={};
lbg = [];
ubg = [];

% Constraints for initial state
Xk = MX.sym('X0', 4);
w = {w{:}, Xk};
lbw = [lbw; 0; 0; 0; 0];
ubw = [ubw; 0; 0; 0; 0];
w0 = [w0; 0; 0; 0; 0];

% Formulate the NLP
for k=0:N-1
  % New NLP variable for the control
  Uk = MX.sym(['U_' num2str(k)]);
  w = {w{:}, Uk};
  lbw = [lbw; -uMax];  % Control bounds
  ubw = [ubw;  uMax];
  w0 = [w0;  0];       % Initial guess for control
  
  % Integrate dynamics and cost
  Fk = F('x0', Xk, 'p', Uk);
  Xk_end = Fk.xf;
  J=J+Fk.qf;
  
  % New NLP variable for state at end of interval
  Xk = MX.sym(['X_' num2str(k+1)], 4);
  w = [w, {Xk}];
  
  if k == N-1
    % Constraints on state for final condition
    lbw = [lbw; 0; 0; pi; 0];
    ubw = [ubw;  0; 0; pi; 0];
  else
    % Constraints on state
    lbw = [lbw; -1; -inf; -inf; -inf];
    ubw = [ubw;  1;  inf; inf; inf];
  end
  
  w0 = [w0; 0; 0; 0; 0]; % Initial guess for state
  
  % Dynamics constraint
  g = [g, {Xk_end-Xk}];
  lbg = [lbg; 0; 0; 0; 0];
  ubg = [ubg; 0; 0; 0; 0];
end

%% Create an NLP solver
prob = struct('f', J, 'x', vertcat(w{:}), 'g', vertcat(g{:}));
solver = nlpsol('solver', 'ipopt', prob);

% Solve the NLP
sol = solver('x0', w0, 'lbx', lbw, 'ubx', ubw,...
  'lbg', lbg, 'ubg', ubg);
w_opt = full(sol.x);

%% Plot the solution
x_opt = w_opt(1:5:end);
v_opt = w_opt(2:5:end);
theta_opt = w_opt(3:5:end);
omega_opt = w_opt(4:5:end);
u_opt = w_opt(5:5:end);
tgrid = linspace(0, T, N+1);


f = figure;
f.Position = [100 100 960 600];
s1 = subplot(2,1,1);

htt = plot(tgrid(end), pi, 'ro');
hold on

hx = plot(tgrid, x_opt, 'k--');
hv = plot(tgrid, v_opt, 'b--');
ht = plot(tgrid, theta_opt, 'r-');
hw = plot(tgrid, omega_opt, 'm-');

xlabel('t')
legend([htt hx hv ht hw], {"target \theta", "x", "v", "\theta", "\omega"})
grid on
s1.FontSize = 18;

s2 = subplot(2,1,2);
stairs(tgrid, [u_opt; nan], '-.','color',[0 0.5 0])
grid on
s1.FontSize = 18;
xlabel('t')
ylabel('F(t)')