function diff_flat()

%% Computing flat outputs
% Time horizon
T = 10; 

% Matrix for linear equation representing constraints in flat output space
M = [1 0 0 0; 0 1 0 0; 1 T T^2 T^3; 0 1 2*T 3*T^2]; 

% RHS of constraints in flat output space
x_constr = [0; 1; 0; 0];
y_constr = [0; 0; 0; 1];

% Solve for coefficients of basis functions
b0 = M\x_constr;
b1 = M\y_constr;
% Note: lengths of b0 and b1: 4

%% Computing state and control trajectories from flat outputs
dt = 0.01;
t = 0:dt:T;

% First, we compute x, y, and their derivatives; these are analytic since
% the basis functions are monomials
x = zeros(size(t));
y = zeros(size(t));
% x and y have powers of t from 0 to length(b0)-1
for i = 0:length(b0)-1 
    x = x + b0(i+1) * t.^i;
    y = y + b1(i+1) * t.^i;
end

xdot = zeros(size(t));
ydot = zeros(size(t));
% xdot and ydot have powers of t from 0 to length(b0)-2
for i = 0:length(b0)-2
    xdot = xdot + (i+1)*b0(i+2)*t.^i;
    ydot = ydot + (i+1)*b1(i+2)*t.^i;
end

xddot = zeros(size(t));
yddot = zeros(size(t));
% xddot and yddot have powers of t from 0 to length(b0)-3
for i = 0:length(b0)-3
    xddot = xddot + factorial(i+2)*b0(i+3)*t.^i;
    yddot = yddot + factorial(i+2)*b1(i+3)*t.^i;
end

% Finally, we have the theta and v trajectories (x and y trajectories have
% already been computed)
theta = atan2(ydot, xdot);
v = xdot./cos(theta);
% Use alternate expression for v when cos(theta) == 0
% Other option: use v = sqrt(xdot^2 + ydot^2)
small = 1e-5;
cos_zero_inds = cos(theta) < small;
v(cos_zero_inds) = ydot(cos_zero_inds)./sin(theta(cos_zero_inds));

% Control trajectories
omega = (yddot.*xdot - xddot.*ydot)./v.^2;
a = (xdot.*xddot + ydot.*yddot)./v;

%% Plot
f1 = figure;
f1.Position = [100 100 2400 1200];

% Path in x-y space
s1 = subplot(2,4,[1 2 5 6]);
plot(x,y, "linewidth", 3);
title("Path of Car", "Interpreter", "Latex")
xlabel("$x$", "Interpreter", "Latex")
ylabel("$y$", "Interpreter", "Latex")
grid on
xlim([-0.1 1.5])
ylim([-1.5 0.1])
axis square
s1.FontSize = 18;


% State trajectory over time
s2 = subplot(2,4,[3 4]);
plot(t,x, "linewidth", 3);
hold on
plot(t,y, "linewidth", 3);
plot(t,theta, "linewidth", 3);
plot(t,v, "linewidth", 3);
title("State Trajectories", "Interpreter", "Latex")
legend({"$x$", "$y$", "$\theta$", "$v$"}, "Interpreter", "Latex")
grid on
s2.FontSize = 18;

% Control trajectory over time
s3 = subplot(2,4,[7 8]);
plot(t,omega, "linewidth", 3)
hold on
plot(t,a, "linewidth", 3)
title("Control Trajectories", "Interpreter", "Latex")
legend({"$\omega$", "$a$"}, "Interpreter", "Latex")
xlabel("$t$", "Interpreter", "Latex")
grid on
s3.FontSize = 18;
end