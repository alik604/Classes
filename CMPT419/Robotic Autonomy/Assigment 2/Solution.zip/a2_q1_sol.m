function sqp()

% Grid for plotting
X = -1:0.01:1;
Y = -1:0.01:1;
[x,y] = ndgrid(X,Y);

f = figure;
f.Position = [100 100 1600 600];
subplot(1,2,1) % Surf (3D) plot
surf(x,y,fun(x,y), "edgealpha", 0.1, "facealpha", 0.5)
drawnow
hold on

subplot(1,2,2) % Contour (2D) plot
contour(x,y,fun(x,y))
axis square
drawnow
hold on

num_ics = 20; % Number of initial conditions
colors = lines(num_ics);

maxIter = 25;
small = 1e-3; % Tolerance for convergence
alpha = 0.25; % Step size

for ii = 1:num_ics
  % Random initial conditions
  xk = -1+2*rand;
  yk = -1+2*rand;
  
  % Sequence of iterates
  xks = xk;
  yks = yk;
  
  
  
  % Plot initial conditions
  subplot(1,2,1) 
  plot3(xk, yk, fun(xk,yk), '.', 'color', colors(ii,:), 'markersize', 15);
  drawnow;
  
  subplot(1,2,2)
  plot(xk, yk, '.', 'color', colors(ii,:), 'markersize', 15);
  drawnow;
  
  
  % Repeatedly solve quadratic subproblem
  for i = 1:maxIter
    
    dk = solve_quad_subproblem(xk, yk);
    xk = xk + alpha*dk(1);
    yk = yk + alpha*dk(2);
    xks = [xks xk];
    yks = [yks yk];
    
    % Convergence condition
    if norm(dk) <= small
      break
    end
  end
  
  % Plot sequence of iterates
  subplot(1,2,1)
  plot3(xks, yks, fun(xks,yks), '.-', 'color', colors(ii,:), ...
    "linewidth", 2.5);
  drawnow;
  
  subplot(1,2,2)
  plot(xks, yks, '.-', 'color', colors(ii,:));
  drawnow;
end
end

function z = fun(x,y)

z = sin(pi*x).*sin(2*pi*y);

end

function dk = solve_quad_subproblem(xk, yk)
% Solves the quadratic subproblem using cvx

dz = grad_fun(xk, yk); % gradient
Hz = hess_fun(xk, yk); % Hessian

% Convexify Hessian
[V,D] = eig(Hz);
D(D<=0) = 0;
Hz = V*D*V^-1;

% Solve problem in cvx
cvx_quiet true
cvx_begin
% Decision variable
variable dk(2)

% Quadratic objective
minimize ( 0.5*quad_form(dk, Hz) + dz'*dk )

% Constraints
-xk - dk(1) - 1 <= 0
xk + dk(1) - 1 <= 0
-yk - dk(2) - 1 <= 0
yk + dk(2) - 1 <= 0

cvx_end

end

function dz = grad_fun(x,y)
% Gradient of objective function
dz = [pi*cos(pi*x)*sin(2*pi*y); 2*pi*sin(pi*x)*cos(2*pi*y)];
end

function Hz = hess_fun(x,y)
% Hessian of objective function
z11 = -pi^2 * sin(pi*x) * sin(2*pi*y);
z12 = 2*pi^2*cos(pi*x)*cos(2*pi*y);
z22 = -4*pi^2*sin(pi*x)*sin(2*pi*y);
Hz = [z11 z12; z12 z22];
end