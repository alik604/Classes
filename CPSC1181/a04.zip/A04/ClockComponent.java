//package A04;

import java.awt.*;
import java.util.Timer;

import javax.swing.JComponent;

public class ClockComponent extends JComponent {

	/**
	 * Instantiates a new clock component.
	 */
	public ClockComponent() {
	}

	public void paint(Graphics g) {
		// the frame's dimensions
		final int w = getWidth(); // width
		final int h = getHeight(); // height

		// clear the specified rectangle by filling it with the background
		// color
		// useful when resizing because we want to erase what there was before
		g.clearRect(0, 0, w, h);
		g.drawRect(0, 0, w, h);//w-1, h-1
		// set up our transform to be relative to a 200x200 box
		Graphics2D g2 = (Graphics2D) g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		// move to center
		g2.translate(w / 2.0, h / 2.0);
		// scale
		int min = Math.min(w, h);
		double scaleFactor = min / (double) Clock.SCALE;
		g2.scale(scaleFactor, scaleFactor);
		// move to top left of bound
		g2.translate(-Clock.CENTRE, -Clock.CENTRE);

		// draw the 200x200 box
		Clock c = new Clock();
		c.draw(g2);

		g2.dispose();

	}
}
