//package A04;

import java.time.LocalTime;

public class HandTester {

	private final static double RADIANS = Math.PI * 2;

	private final static double EPSILON = 1E-12;

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 */
	public static void main(String[] args) {
		test_0();
		test_12();
		test_maxHour();
		test_midNight();
		test_min0();
		test_min30();
		test_mins59();
		test_sec0();
		// test_secNull();
		test_1_30();

		// TODO FIXME write more tests
		// assert false;
		System.err.println("PASS");
	}

	/**
	 * Test 0.
	 */
	private static void test_0() {
		LocalTime time = LocalTime.MIN;
		Hand hours = new Hand(Hand.TimeUnit.HOUR, time);
		assert 0 == hours.angle;
	}

	/**
	 * Test 12.
	 */
	private static void test_12() {
		LocalTime time = LocalTime.NOON;
		Hand hours = new Hand(Hand.TimeUnit.HOUR, time);
		assert 0 == hours.angle;
	}

	/**
	 * Test max hour.
	 */
	private static void test_maxHour() {// test 11 O'clock,59 mins
		LocalTime time = LocalTime.MAX;
		Hand mins = new Hand(Hand.TimeUnit.MINUTE, time);
		Hand hours = new Hand(Hand.TimeUnit.HOUR, time, mins);
		assert 359.5 == hours.angle;
	}

	/**
	 * Test mid night.
	 */
	private static void test_midNight() {
		LocalTime time = LocalTime.MIDNIGHT; // 0 O'clock
		Hand hours = new Hand(Hand.TimeUnit.HOUR, time);
		assert 0 == hours.angle;
	}

	/**
	 * Test min 0.
	 */
	// ----- mins
	private static void test_min0() {
		LocalTime time = LocalTime.MIN; // check at 0 mins
		Hand mins = new Hand(Hand.TimeUnit.MINUTE, time);
		assert 0 == mins.angle;
	}

	/**
	 * Test min 30.
	 */
	private static void test_min30() {
		LocalTime time = LocalTime.of(0, 30);// check at 30 mins
		Hand mins = new Hand(Hand.TimeUnit.MINUTE, time);
		assert 180 == mins.angle;
	}

	/**
	 * Test mins 59.
	 */
	private static void test_mins59() {// double checking this case, was tested
										// in maxHour
		LocalTime time = LocalTime.MAX;// check at 59 mins
		Hand mins = new Hand(Hand.TimeUnit.MINUTE, time);
		assert 354 == mins.angle;
	}

	/**
	 * Test sec 0.
	 */
	// -----------------seconds
	private static void test_sec0() {
		LocalTime time = LocalTime.MIN;
		Hand secs = new Hand(Hand.TimeUnit.SECOND, time);
		assert 0 == secs.angle;
	}

	/**
	 * Test sec null.
	 */
	// ---------- what if null?
	private static void test_secNull() {
		// no clue how to do this since variables in Hand.java are final
		// could over load hand construct a 3rd and/or 4th time, but will cause
		// issues (nullpointer)
		LocalTime time = (LocalTime) null;
		Hand secs = new Hand(Hand.TimeUnit.SECOND, time);
		assert 0 == secs.angle;
	}

	/**
	 * Test 1 30.
	 */
	private static void test_1_30() {// test 1:30
		LocalTime time = LocalTime.of(1, 30, 00);// check at 30 mins

		Hand mins = new Hand(Hand.TimeUnit.MINUTE, time);
		Hand hours = new Hand(Hand.TimeUnit.HOUR, time, mins);
		assert 45 == hours.angle;
	}

	// ** Do Not Change Below this line ** //

	/**
	 * Assert equals.
	 *
	 * @param exp
	 *            the exp
	 * @param act
	 *            the act
	 */
	private static void assertEquals(double exp, double act) {
		assert Math.abs(exp - act) <= EPSILON : "\nexp: " + exp + "\nact: " + act + "\ndif: " + (exp - act);
	}

	static {
		boolean assertsEnabled = false;
		assert assertsEnabled = true; // Intentional side effect!!!
		if (!assertsEnabled) {
			throw new RuntimeException("Asserts must be enabled!!! java -ea");
		}
	}
}
