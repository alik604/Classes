//package A04;

import java.awt.*;
import java.time.LocalTime;
import java.time.temporal.ChronoField;

public class Hand {

	public final static double RADIANS = Clock.RADIANS;

	public enum TimeUnit {

		MILLS(ChronoField.MILLI_OF_SECOND, 0, 0),

		SECOND(ChronoField.SECOND_OF_MINUTE, 80, 0.5f, Color.RED),

		MINUTE(ChronoField.MINUTE_OF_HOUR, 90, 1),

		HOUR(ChronoField.HOUR_OF_AMPM, 60, 2);

		public final ChronoField cf;

		public final int length;

		public final BasicStroke stroke;

		public final Color color;

		/**
		 * Instantiates a new time unit.
		 *
		 * @param aCF
		 *            the a CF
		 * @param aLength
		 *            the a length
		 * @param aWidth
		 *            the a width
		 */
		TimeUnit(ChronoField aCF, int aLength, float aWidth) {
			this(aCF, aLength, aWidth, Color.BLACK);
		}

		/**
		 * Instantiates a new time unit.
		 *
		 * @param aCF
		 *            the a CF
		 * @param aLength
		 *            the a length
		 * @param aWidth
		 *            the a width
		 * @param aColor
		 *            the a color
		 */
		TimeUnit(ChronoField aCF, int aLength, float aWidth, Color aColor) {
			cf = aCF;
			length = (Clock.SCALE * aLength) / (100 * 2);
			stroke = new BasicStroke(aWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
			color = aColor;
		}
	}

	private final TimeUnit unit; // ie: hour, minute, second, etc
	public final double angle;
	// the rotation of the hand in degrees from 12 o'clock
	public final double time;

	public final double unitCFrange;
	// unit CF range <- to many caps will make it hard to read.

	/**
	 * Instantiates a new hand.
	 *
	 * @param aUnit
	 *            the a unit
	 * @param aTime
	 *            the a time
	 */
	public Hand(TimeUnit aUnit, LocalTime aTime) {
		this(aUnit, aTime, null);
	}

	/**
	 * Instantiates a new hand.
	 *
	 * @param aUnit
	 *            the a unit
	 * @param aTime
	 *            the a time
	 * @param prevHand
	 *            the prev hand
	 */
	public Hand(TimeUnit aUnit, LocalTime aTime, Hand prevHand) {

		unit = aUnit;
		// TODO FIXME calculate the angle
		// use LocalTime->get
		// unit.cf
		// ChronoField-> range().getMaximum()
		// and preHand.angle
		// --------------------------------------

		time = aTime.get(unit.cf);

		unitCFrange = aUnit.cf.range().getMaximum();// 59,59, or 11

		double angleDistubution = 360 / (1 + unitCFrange);
		// instead of just 30 or 6 degrees

		if (unit.cf == ChronoField.HOUR_OF_AMPM && prevHand != null) {
			angle = (time + prevHand.time / 60.0) % 12 * angleDistubution;
		} else if (unit.cf == ChronoField.HOUR_OF_AMPM) {
			angle = time * angleDistubution;
		} else {
			angle = time * angleDistubution;
		}
	}

	/**
	 * Draw.
	 *
	 * @param g
	 *            the Graphics2D
	 */
	public void draw(Graphics2D g) {
		double angleRad = Math.toRadians(angle);
		int lengh = 0;

		switch (unit.cf) {

		case SECOND_OF_MINUTE: {
			g.setColor(Color.red);
			lengh = 72;
			break;
		}

		case MINUTE_OF_HOUR: {
			g.setColor(Color.LIGHT_GRAY);
			lengh = 60;
			break;
		}
		case HOUR_OF_AMPM: {
			g.setColor(Color.DARK_GRAY);
			lengh = 50;
			break;
		}
		default:
			lengh = 150;// easy to see
		}

		g.drawLine((int) (100 + lengh * Math.sin(angleRad)), (int) (100 + -lengh * Math.cos(angleRad)), 100, 100);
		// i thought a line you a go in better with my design
	}
}
