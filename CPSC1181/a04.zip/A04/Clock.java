//package A04;

import java.time.LocalDate;
import java.time.LocalTime;
import java.awt.*;

import A04.Hand.TimeUnit;

public class Clock {

	public final static double RADIANS = 2 * Math.PI;

	public final static int SCALE = 200;

	public final static int CENTRE = SCALE / 2;

	private final static int NUM_TICKS = 12;

	private LocalTime time;

	private LocalDate date = LocalDate.now();

	/**
	 * Instantiates a new clock.
	 */
	public Clock() {
		this(LocalTime.now());
	}

	/**
	 * Instantiates a new clock.
	 *
	 * @param aTime
	 *            which becomes the time
	 */
	public Clock(LocalTime aTime) {
		time = aTime;
	}

	/**
	 * Draw clock
	 *
	 * @param g
	 *            the Graphics2D
	 */
	public void draw(Graphics2D g) {

		// center decoration
		int point = 40;
		g.setColor(Color.magenta);

		for (int i = 0; i < point; i++) {
			g.fillRoundRect(95, 100, 2, 10, 10, 10);
			g.rotate(RADIANS / point, 100, 100);
		}
		g.setColor(Color.black);

		// edge
		g.drawArc(12, 12, 175, 175, 0, 360);

		// date in writing
		g.drawString(date.toString(), 72, 140);

		// time in writing
		String mins = (time.getMinute() < 10) ? "0" + time.getMinute() : "" + time.getMinute();
		int hour = (time.getHour() % 12 == 0) ? 12 : time.getHour() % 12;
		g.drawString("" + hour + ":" + mins, 85, 63);

		// hour points
		for (int i = 0; i < NUM_TICKS; i++) {
			if (i % 3 == 0) {
				g.setColor(Color.DARK_GRAY);
				g.fillRoundRect(93, 21, 12, 22, 10, 10);// <- fill dont draw
				g.setColor(Color.GRAY);
			} else {
				g.fillRoundRect(95, 22, 8, 22, 10, 10);
			}
			g.rotate(Math.toRadians(30), 100, 100);
		}
		g.rotate(Math.toRadians(4), 100, 100);
		g.rotate(-RADIANS / 90, 100, 100); // help with alignment -rad/120 <-
											// old way
		// second points
		for (int i = 0; i < 60; i++) {
			if (i % 5 == 0) {
				g.setColor(Color.MAGENTA);
			} else {
				g.setColor(Color.RED);
				g.fillRoundRect(98, 25, 2, 10, 10, 10);
			}
			g.rotate(RADIANS / 60, 100, 100);
		}
		// center (cap on hands)
		g.fillArc(95, 95, 10, 10, 0, 360);

		// get hands & invoke draw upon them
		Hand[] arry = getHands();
		arry[0].draw(g);
		arry[1].draw(g);
		arry[2].draw(g);

	}

	/**
	 * Gets the hands.
	 *
	 * @return the hands
	 */
	public Hand[] getHands() {
		Hand handSec = new Hand(TimeUnit.SECOND, time);
		Hand handMin = new Hand(TimeUnit.MINUTE, time, handSec);// passing in
																// previous hand
		Hand handHour = new Hand(TimeUnit.HOUR, time, handMin);

		Hand[] arry = { handSec, handMin, handHour };

		return arry;
	}

}