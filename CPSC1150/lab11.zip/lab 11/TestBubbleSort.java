/*
 *Program Name:	TestBubbleSort.java
 *Author:		Khizr ali pardhan
 *Date:		2017-03-30
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 
 
 i'm not sure if your wanted user input. i assumed yes, but kept line for direct input commented out. 
 
 
 */
 import java.util.Scanner;
public class TestBubbleSort {
	public static void main(String[] args) {
		// create array of values to sort
		//int[] array = { 9, 8, 70, 6, 8, 54, 3, 1, 2 };
		
      Scanner scan = new Scanner(System.in);
		// create empty array
		int[] array = new int[6];
		// set values to array
		System.out.println("please enter 6 numbers to sort");
		for (int x = 0; x < array.length; x++) {
			array[x] = scan.nextInt();
      }
      // execute bubble sort
		bubbleSort(array);
		// print array
		for (int i = 0; i < array.length - 1; i++)
			System.out.printf(array[i] + ", ");

		System.out.println(array[array.length - 1]);

	}// main

	public static void bubbleSort(int[] list) {
		// cheack if no change
		boolean changed = true;
		do {
			// assume array is not changed
			changed = false;
			/*
			 * loop tohught array
			 * if next value is greater then current value
			 * swap values and set changed value to true
			 */
			for (int j = 0; j < list.length - 1; j++)
				if (list[j + 1] > list[j]) {
					// swap list[j] with list[j + 1]
					int temp = list[j];
					list[j] = list[j + 1];
					list[j + 1] = temp;

					changed = true;
				}
		} while (changed);// if array is changed, run again

	}
}// class