/*
 *Program Name:	PlayLottery.java
 *Author:		Khizr ali pardhan
 *Date:		2017-03-30
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */

import java.util.Scanner;

/**
        getUserNumbers() returns itself if there is an error... seem to
              be a good way to handle invaild input
 */
public class PlayLottery {
	public static void main(String[] args) {

		// assign array to return array of getRandomNumber()
		int[] randomNumbers = getRandomNumber();

		// print the ranNumbers array
		for (int x = 0; x < randomNumbers.length; x++)
			System.out.println(randomNumbers[x]);
		System.out.println("^ random numbers");

		// get user Numbers
		int[] userNumbers = getUserNumbers();

		// print number of mating numbers
		System.out.println("the total number of matched numbers is: "
				+ getTotalMatchedNumbers(userNumbers, randomNumbers));

	}// main

	public static int[] getRandomNumber() {
		// create empty array
		int[] randomNumbers = new int[6];
		// for loop of length of array
		for (int i = 0; i < randomNumbers.length; i++) {
			// bool check call true
			boolean check = true;
			// make random int
			int x = (int) (Math.random() * 49) + 1;
			// for loop of length of array
			for (int o = 0; o < randomNumbers.length; o++) {
				// check if random number is in any int index of array
				if (randomNumbers[o] == x)
					check = false;
			}
			// if random number is not in array, add it
			if (check)
				randomNumbers[i] = x;
			else
				// if random number is in array, run for loop one more time
				i--;
		}
		// loop though array print each value
		// for (int i = 0; i < randomNumbers.length; i++) {
		// System.out.printf(randomNumbers[i] + " ");
		// }

		// return random numbers array
		return randomNumbers;
	}

	public static int[] getUserNumbers() {
		// create scanner object
		Scanner scan = new Scanner(System.in);
		// create empty array
		int[] userNumbers = new int[6];
		// set values to array
		System.out.println("please enter 6 distinct numbers between 1 and 49");
		for (int x = 0; x < userNumbers.length; x++) {
			userNumbers[x] = scan.nextInt();
			// dealt with invalid numbers
			if (userNumbers[x] > 49 || userNumbers[x] < 1) {
				System.out.println("out of range");
				// //////////////////////////////return getUserNumbers();
				break;
			}
			// loop thought array and cheack for double values
			for (int j = 0; j < userNumbers.length; j++) {
				if (x != j && userNumbers[x] == userNumbers[j]) {
					System.out.println("double value found: " + userNumbers[j]
							+ " and " + userNumbers[x]);
					return getUserNumbers();
				}
			}
		}
		// for (int i = 0; i < userNumbers.length; i++) { }
		// return user user numbers array
		return userNumbers;
	}

	public static int getTotalMatchedNumbers(int[] userNumbs, int[] randomNumbs) {
		// create matched numbers variable
		int numb = 0;
		// run double for loop, cheack for matching values. if found increment
		// matched numbers variable
		for (int i = 0; i < randomNumbs.length; i++) {
			for (int j = 0; j < userNumbs.length; j++) {
				if (randomNumbs[i] == userNumbs[j]) {
					numb++;
				}

			}
		}
		// reurn matched numbers variable
		return numb;
	}
}// class