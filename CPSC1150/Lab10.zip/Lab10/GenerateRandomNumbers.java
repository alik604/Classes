
/*
 *Program Name:	generaterandomnumber.java
 *Author:		Khizr ali pardhan
 *Date:		Saturday, March 25, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */

public class GenerateRandomNumbers {
	public static void main(String[] args) {
		// create int array of length 6
		int[] randomNumber = new int[6];
		// for loop of length of array
		for (int i = 0; i < randomNumber.length; i++) {
			// bool check call true
			boolean check = true;
			// make random int
			int x = (int) (Math.random() * 49) + 1;
			// for loop of length of array
			for (int o = 0; o < randomNumber.length; o++) {
				// check if random number is in any int index of array
				if (randomNumber[o] == x)
					check = false;
			}
			// if random number is not in array, add it
			if (check)
				randomNumber[i] = x;
			else
				// if random number is in array, run for loop one more time
				i--;
		}
		// loop though array print each value
		for (int i = 0; i < randomNumber.length; i++) {
			System.out.printf(randomNumber[i] + " ");
		}
	}// main
}// class

