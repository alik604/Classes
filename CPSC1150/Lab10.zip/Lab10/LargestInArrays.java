import java.util.Scanner;

/*
 *Program Name:	largestarray.java
 *Author:		Khizr ali pardhan
 *Date:		Saturday, March 25, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */

public class LargestInArrays {

	public static void main(String[] args) {
		// create scanne object
		Scanner scan = new Scanner(System.in);
		// creat int array, lenght 5
		int[] arry = new int[5];
		System.out.println("please enter five number");
		for (int i = 0; i < arry.length; i++)
			// set values for int array
			arry[i] = scan.nextInt();
		// call and print max
      System.out.println("largest is...");
		System.out.println(max(arry));
      System.out.println();
		
		// crate double array,of lenght 5
		double[] arry2 = new double[5];
		System.out.println("please enter five number");
		for (int i = 0; i < arry.length; i++)
			// set values for double array
			arry2[i] = scan.nextDouble();
		// call and print max
      System.out.println("largest is...");
		System.out.println(max(arry2));

	}// main

	public static int max(int[] array) {
		// set max is first value of array
		int max = array[0];
		// loop thought rest of array.
		for (int i = 1; i < array.length; i++) {
			// if a value is greater then max; set it to max
			if (array[i] > max)
				max = array[i];

		}
		// return max
		return max;

	}

	public static double max(double[] array) {
		// set max is first value of array
		double max = array[0];
		for (int i = 1; i < array.length; i++) {
			// if a value is greater then max; set it to max
			if (array[i] > max)
				max = array[i];

		}
		// retuen max
		return max;
	}

}// class

