import java.util.Scanner;

/*
 *Program Name:	displayweeklytempstats.java
 *Author:		Khizr ali pardhan
 *Date:		Saturday, March 25, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */

public class DisplayWeekTempStat {

	public static void main(String[] args) {
		// create a scanner object
		Scanner scan = new Scanner(System.in);
		// string array of day names
		String[] dayName = { "Sunday", "Monday", "Tuesday", "Wednesday",
				"Thursday", "Friday", "Saturday" };

		System.out
				.println("Please enter the highest temperature of each day in a week (start with Sunday):");
		// array to store temp of each day
		int[] daily = new int[7];
		// set values to array
		for (int i = 0; i < daily.length; i++) {
			daily[i] = scan.nextInt();
		}
		System.out.println();// new line
		// print average temp
		System.out.printf(
				"The average temperature of the week is: %.2f degree\n",
				avg(daily));
		// print hottest temp
		System.out.println("The hottest temperature is " + hottest(daily)
				+ " degree");
		// print coldest temp
		System.out.println("The coldest temperature is " + coldest(daily)
				+ " degree");
		/*
		 * print title create int array of day of hottest day (or coldest) for
		 * length of said array set a temp variable to value of array. print
		 * dayName of index of temp if i != hotDays.length - 1 && hotDays.length
		 * > 1 ; print and ','
		 */
		System.out.printf("The hottest days are: ");

		int[] hotDays = searchTemp(daily, hottest(daily));

		for (int i = 0; i < hotDays.length; i++) {
			int temp = hotDays[i];
			System.out.printf(dayName[temp]);
			if (i != hotDays.length - 1 && hotDays.length > 1)
				System.out.printf(", ");
		}
		System.out.printf("\nThe coldest days are: ");
		int[] coldDays = searchTemp(daily, coldest(daily));
		//
		for (int i = 0; i < coldDays.length; i++) {
			int temp = coldDays[i];
			System.out.printf(dayName[temp]);
			if (i != coldDays.length - 1)
				System.out.printf(", ");
		}

		// for (int i = 0; i < daily.length; i++)
		// System.out.println(i + " is: " + daily[i]);

	}// main

	public static int[] searchTemp(int[] arry, int key) {
		// set int x to number of "int key' valued variable is arry
		int x = 0;

		for (int i = 0; i < arry.length; i++) {
			if (arry[i] == key)
				x++;
		}
		// create new array of length x
		int[] hottestDay = new int[x];
		// make int k =0
		int k = 0;
		// of each index of array, if arry ==key set hottest day with index k to
		// i. increment k
		for (int i = 0; i < arry.length; i++) {
			if (arry[i] == key) {
				hottestDay[k] = i;
				k++;
			}
		}
		/*
		 * for (int i = 0; i < hottestDay.length; i++) {
		 * System.out.println(hottestDay[i]); System.out.println(dayName[i]); }
		 */
		// return array of day with have "key"
		return hottestDay;
	}

	public static double avg(int[] arry) {
		/*
		 * set double avg to index 0, go tough loop adding value to avg. return
		 * avg/arry.length
		 */
		double avg = arry[0];

		for (int i = 1; i < arry.length; i++) {
			avg += arry[i];
		}
		avg /= arry.length;
		return avg;

	}

	public static int hottest(int[] arry) {
		/*
		 * set hottest to index 0 of array. use for loop to find hottest
		 */
		int hottest = arry[0];
		for (int i = 1; i < arry.length; i++) {
			if (arry[i] > hottest)
				hottest = arry[i];
		}

		return hottest;
	}

	public static int coldest(int[] arry) {
		/*
		 * set coldest to index 0 of array. use for loop to find coldest
		 */
		int coldest = arry[0];
		for (int i = 1; i < arry.length; i++) {
			if (arry[i] < coldest)
				coldest = arry[i];
		}
		return coldest;
	}

}// class