/*
 *Program Name:	AllVowels.java
 *Author:		Khizr ali pardhan
 *Date:		march 2nd, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */


public class AllVowels {

	// main
	public static void main(String[] args) {
		//string names str to show results
		String str = "";
		// char to hold randome letter
		char random = 0;
		//while loop which gones on till forever
		while (true) {
			//loop exit condition 
			if (str.length() >= 4)
				//exit loop with break
				break;
			//gernrate randome latter given ascii range 
			random = (char) (Math.random() * 26 + 97);// a is 97 and z is 122
			// System.out.println(random);
			//cheack for vowel, if found: add to str
			if (random == 'a')
				str += "a";

			else if (random == 'e')
				str += "e";

			else if (random == 'i')
				str += "i";

			else if (random == 'o')
				str += "o";

			else if (random == 'u')
				str += "u";

			// else if (random == 'z') str += "zzzzzzzzzzzzzzzzzzzzzzzzzzz";
			// ^ confirms i get at chars from a-z
			/*
			 * switch (random) { case 97: str += "a"; break;
			 * 
			 * case 1: str += "e"; break;
			 * 
			 * case 2: str += "i"; break;
			 * 
			 * case 3: str += "o"; break;
			 * 
			 * case 4: str += "u"; break; }
			 */
		}
		// print list of vowels 
		System.out.println(str);
	}// main
}