/*
 *Program Name:	DisplayCalender.java
 *Author:		Khizr ali pardhan
 *Date:		march 2nd, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */
 import java.util.Scanner;
public class DisplayCalendar{
   
   // main
	public static void main(String[] args) {
		// make scanner object
		Scanner scan = new Scanner(System.in);
		// get year as input
		System.out.println("Enter a year: ");
		int year = scan.nextInt();
		//get first day as input
		System.out.println("Enter the first day of the year (sunday is 0): ");
		int firstDayNumb =scan.nextInt();
		// add one to first day
		firstDayNumb++;

		int firstDayNumb2 = 0;//unused
		// cheack for leap year
		boolean isLeapYear = ((year % 4 == 0) && (year % 100 != 0))
				|| (year % 400 == 0);
		// add day in month variable
		int dayInMonth = 0;
		// add variavle to hold month
		String month = "";
		// forloop for month
		for (int i = 1; i <= 12; i++) {
		// switch to assign month
			switch (i) {
			case 1:
				month = "January";
				dayInMonth = 31;
				break;
			case 2:
				month = "February";
				if (isLeapYear)
					dayInMonth = 29;
				else
					dayInMonth = 28; // if leap year 29, else 28
				break;
			case 3:
				month = "March";
				dayInMonth = 31;
				break;
			case 4:
				month = "April";
				dayInMonth = 30;
				break;
			case 5:
				month = "May";
				dayInMonth = 31;
				break;
			case 6:
				month = "June";
				dayInMonth = 30;
				break;
			case 7:
				month = "July";
				dayInMonth = 31;
				break;
			case 8:
				month = "August";
				dayInMonth = 31;
				break;
			case 9:
				month = "September";
				dayInMonth = 30;
				break;
			case 10:
				month = "October";
				dayInMonth = 31;
				break;
			case 11:
				month = "November";
				dayInMonth = 30;
				break;
			case 12:
				month = "December";
				dayInMonth = 31;
				break;
			default:
				month = "Invalid month";
				break;
			}// end of switch
			// formatting
			System.out.println();
			System.out.println("       " + month + "    " + year);
			System.out.println("____________________________________");
			// more formating
			System.out.println(" Sun   Mon   Tue   Wed   Thu   Fri   Sat");
			// create spacing
			if (firstDayNumb == 1)//number entered is 0, its sunday
				System.out.printf(" ");
			 
         else if (firstDayNumb == 2)//number enters is 1, its mon
			 System.out.printf("       ");
			 
         else if (firstDayNumb == 3)//number enters is 2, its tuesday
         System.out.printf("             ");
                  
         else if (firstDayNumb == 4)//number enters is 3, its wednesday
				 System.out.printf("                   ");
          
         else if (firstDayNumb == 5)//number enters is 4, its thursday
				 System.out.printf("                         ");
         //thursday
         else if (firstDayNumb == 6)//number enters is 5, its friday
					System.out.printf("                               ");
         else if (firstDayNumb == 7)//number enters is 6, its saturday
           
					System.out.printf("                                     ");
		//	else {
							
				//my crazy way to add spacing
	//			for (int space = 1; space <= firstDayNumb; space++) {
	//				System.out.print("     ");
		//		}
	//		}// end of else

			// ***** above happens once a month,every month****
			//***below for everyday of the given month***
			for (int day = 1; day <= dayInMonth; day++) {
			// print out dates
				if (day <= 9)
					System.out.print(day + "     ");
				else
					System.out.print(day + "    ");
				if ((day + firstDayNumb - 1) % 7 == 0) {
					System.out.println();
					System.out.printf(" ");// every new line starts with a space
											// }
				}
			}
			//find first day of next month. ( not need for last month, i doubt adding an *IF* will increase efficiency in the long run)
			firstDayNumb = (firstDayNumb + dayInMonth) % 7;
			// firstDayNumb = (dayInMonth - firstDayNumb) % 7;
			// firstDayNumb2 = (dayInMonth) % 7;
        //extra line to make all this look good
         System.out.println();
		}// end of for loop

	}// main
}