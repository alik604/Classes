/*
 *Program Name:	ValidatingTriangle.java
 *Author:		Khizr ali pardhan
 *Date:		January 26, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */
import java.util.Scanner;
//class
public class ValidatingTriangle{

	public static void main(String[] args) {
	
      // main
		Scanner scan = new Scanner(System.in);
     
      // get input from user
		System.out.println("please enter side #1: ");
		double side1 = scan.nextDouble();

		System.out.println("please enter side #2: ");
		double side2 = scan.nextDouble();

		System.out.println("please enter side #3: ");
		double side3 = scan.nextDouble();
    
      //verify  if its  valid
		boolean bool = ((side1 + side2 > side3) && (side1 + side3 > side2) && (side2
				+ side3 > side1));
    
      //display the output
		System.out.printf("Can edges %.1f,%.1f, and %.1f form a triangle? %b", side1,
				side2, side3, bool);
	}
}
