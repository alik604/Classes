/*
 *Program Name:	SortThreeNumbers.java
 *Author:		Khizr ali pardhan
 *Date:		January 26, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */
import java.util.Scanner;

public class SortThreeNumbers {

	// main
	public static void main(String[] args) {

		// create a scanner object
		Scanner scan = new Scanner(System.in);

		// get input,could use final,but im not worried about over writing variable
		System.out.println("please enter integer 1");
		int number1 = scan.nextInt();

		System.out.println("please enter integer 2");
		int number2 = scan.nextInt();

		System.out.println("please enter integer 3");
		int number3 = scan.nextInt();

		// check for smallest number
		int smallest = number1;

		if (smallest > number2)
			smallest = number2;

		if (smallest > number3)
			smallest = number3;

		// check for largest number
		int largest = number1;

		if (largest < number2)
			largest = number2;

		if (largest < number3)
			largest = number3;

		int middle = 0;
      //find middle number 
		if (number1 != smallest && number1 != largest)
			middle = number1;
		else if (number2 != smallest && number2 != largest)
			middle = number2;
		else if (number3 != smallest && number3 != largest)
			middle = number3;

		// display the output
		System.out.println("smallest is:  " + smallest);
		System.out.println("middle is: " + middle);
		System.out.println("largest is: " + largest);

	}
}