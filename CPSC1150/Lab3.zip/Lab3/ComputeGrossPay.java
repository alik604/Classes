/*
 *Program Name:	ComputeGrossPay.java
 *Author:		Khizr ali pardhan
 *Date:		January 26, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */
import java.util.Scanner;
//class
public class ComputeGrossPay {
	// main
	public static void main(String[] args) {
		
      // create a scanner object 
		Scanner scan = new Scanner(System.in);
		
      // get input from user
      //could use final double hours, to prevent changeing value by mistake 
		System.out.println("hours worked per week?");
		double hours = scan.nextDouble();

		System.out.println("hourly wage?");
		double wage = scan.nextDouble();
		
      // calculate gross pay
		double pay;
		if (hours > 40)
			pay = (hours - 40) * wage * 1.5 + (40 * wage);
		else
			pay = hours * wage;
     //display the output 
		System.out.printf("gross pay is: %.2f", pay);

	}
}