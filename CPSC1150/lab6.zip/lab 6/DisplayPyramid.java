/*
 *Program Name:	DisplayPyramid.java
 *Author:		Khizr ali pardhan
 *Date:		feb 3rd, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */

import java.util.Scanner;
public class DisplayPyramid{
// main
	public static void main(String[] args) {

      // make scanner object 
		Scanner scan = new Scanner(System.in);
      // get input
		System.out.println("please enter number of row you want to print : ");
		int numberOfRows = scan.nextInt();
      // for loop for rows
		for (int row = 0; row <= numberOfRows; row++) {
		// for loop for spaces 
         for (int space = 20; space > row; space--) {
      // makes spaces
				System.out.print("   ");
			}
      // for loop for 1st half
         for (int numb1 = row; numb1 >= 1; numb1--) {
		// print number		
            System.out.print(" " + numb1);
				if (numb1 <= 9)
					System.out.print(" ");
			}
      // for loop for 2nd half
			for (int numb = 2; numb <= row; numb++) {
				if (numb <= 9 && numb != 2) // <-- no clue why i need this.
									System.out.print(" ");
				System.out.print(" " + numb);
			}
      // goto next line 
			System.out.println();
		}

	}

}