/**
 * I'm assuming hitting the current floor should do nothing(rather than displaying elevator again), just like in real life 
 */
import java.util.Scanner;

public class Elevator {
	public static int destinationFloorNumb = 1;
	public static int currentFloorNumb = 1;

	// main
	public static void main(String[] args) {
		int[] reverse = new int[10];
		Scanner scan = new Scanner(System.in);
		System.out.println("o-------o ");
		System.out.println("|   " + currentFloorNumb + "   |");
		System.out.println("o-------o");
		System.out.println("The elevator is at Floor " + destinationFloorNumb
				+ " now");

		while (true) {
			System.out
					.printf("Enter a floor number between 1 and 9, or enter 0 to quit:");
			destinationFloorNumb = scan.nextInt();
			if (destinationFloorNumb == 0) {
				System.out
						.println("Thank you for using the elevator program. Goodbye!");
				System.exit(0);
				// or break out of while loop
			} else if (destinationFloorNumb < 0 || destinationFloorNumb > 9) {
				System.out.println("Invalid floor number. Try again.");
				continue;
			} else if (destinationFloorNumb == currentFloorNumb)
				continue;
			System.out.println("The elevator is moving up from Floor "
					+ currentFloorNumb + " to " + destinationFloorNumb);
			if (destinationFloorNumb > currentFloorNumb)// upwards
			{
				for (; currentFloorNumb - 1 < destinationFloorNumb; currentFloorNumb++) {
					reverse[currentFloorNumb] = currentFloorNumb;
				}
				for (int i = destinationFloorNumb - 0; i > 0; i--) {
					System.out.println("o-------o      /\\ ");
					System.out
							.println("|   " + reverse[i] + "   |    // \\\\ ");
					System.out.println("o-------o   //   \\\\");
				}
			} // if-upward

			else if (destinationFloorNumb < currentFloorNumb)// downwards
				while (currentFloorNumb + 1 > destinationFloorNumb) {

					System.out.println("o-------o   \\\\   // ");
					System.out.println("|   " + currentFloorNumb
							+ "   |    \\\\ // ");
					System.out.println("o-------o      \\/");

					currentFloorNumb--;
				}

			System.out.println("The elevator is at Floor "
					+ destinationFloorNumb + " now");
			currentFloorNumb = destinationFloorNumb;
		}// while true loop

	}// main

}
