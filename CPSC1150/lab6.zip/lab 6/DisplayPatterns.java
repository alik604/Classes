/*
 *Program Name:	DisplayPatterns.java
 *Author:		Khizr ali pardhan
 *Date:		feb 3rd, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */

public class DisplayPatterns{
   //main methord
public static void main(String[] args) {
		//title 
   System.out.println("Pattern I\n");
		//for loop for row
      for (int row = 7; row > 1; row--) {
		// for loop for columns
         for (int col = 1; col < row; col++) {
      // print column number 
				System.out.print(col + " "); // there is a space in word doc

			}
          //next line 
			System.out.println();
        
		}// end of outter for loop
      // title
		System.out.println("\nPattern II");
		//for loop for rows
      for (int row = 0; row < 7; row++) {
			// for loop for spaces
         for (int space = 6; space > row; space--) {
				System.out.print("  ");
			}
         // for loop for number, using row as max ( for shape)
			for (int numb = 1; numb <= row; numb++) {
				// print number
            System.out.print(" " + numb);
			}
			//next line         
			System.out.println();
		}// end of outter loop

	}}