/*
 *Program Name:	CalculateAreaAndPerimeter.java
 *Author:		Khizr ali pardhan
 *Date:		January 11, 2017
 *Course:		CPSC 1150 -2
 *Instructor:	mingwu chen
*/
public class Welcome {
public static void main (String [] args){

System.out.println("Welcome to CPSC1150!");



}

}