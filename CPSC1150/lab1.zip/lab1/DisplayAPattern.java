/*
 *Program Name:	DisplayAPattern.java
 *Author:		Khizr ali pardhan
 *Date:		January 11, 2017
 *Course:		CPSC 1150 -2
 *Instructor:	mingwu chen
*/

public class DisplayAPattern{
 //main metod  
public static void main( String [] args) {   
         // message
      System.out.println("    J       A       V     V     A    ");
      System.out.println("    J      A A       V   V     A A   ");
      System.out.println("J   J     AAAAA       V V     AAAAA  ");
      System.out.println(" J J     A     A       V     A     A ");
 
}
}