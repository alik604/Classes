/*
 *Program Name:	ComputeBalance.java
 *Author:		Khizr ali pardhan
 *Date:		January 19, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
*/
import java.util.Scanner;

//  import util 

public class ComputeBalance{
public static void main(String args[]) {
		// main
		Scanner scan = new Scanner(System.in);
		// scaner obj
		System.out.println("please enter principle:");
		double principle = scan.nextDouble();

		System.out.println("please enter interest rate(in decimals):");
		double rate = scan.nextDouble();

		System.out.println("please enter the number of years: ");
		double year = scan.nextDouble();
		// geting input from user
		double balance = principle * Math.pow(1 + rate, year);
		// calculating balance from input given by user
		System.out
				.printf("the balance is will be: %.2f after %.2f years with rate of %.2f on the initial deposit of %.2f",
						balance, year, rate, principle);
      // output, rounded to two deci points

	}
}