import java.util.Scanner;/*
 *Program Name:	ConvertFeetToMeters.java
 *Author:		Khizr ali pardhan
 *Date:		January 19, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
*/

public class ConvertFeetToMeters{
      //class
	public static void main(String[] args) {
		// method
		Scanner scan = new Scanner(System.in);
		System.out.println("please enter number of feet");
		double feet = scan.nextDouble();
		// input
		double meters = feet * 0.305;
		// display
		System.out.println(feet + " feet in meters is " + meters);
	}
}