/*
 *Program Name:	ComputeTriangleArea.java
 *Author:		Khizr ali pardhan
 *Date:		January 19, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
*/
import java.util.Scanner;
public class ComputeTriangleArea {
      // class
		public static void main(String[] args) {
         // main
         Scanner scan = new Scanner(System.in);
         // scaner OBJ

         System.out.println("enter x1");
         double x1 = scan.nextDouble();

         System.out.println("enter y1");
         double y1 = scan.nextDouble();

         System.out.println("enter x2");
         double x2 = scan.nextDouble();

         System.out.println("enter y2");
         double y2 = scan.nextDouble();

         System.out.println("enter x3");
         double x3 = scan.nextDouble();

         System.out.println("enter y3");
         double y3 = scan.nextDouble();
         // geting 6 inputs from user
         
         double side1 = Math.sqrt(Math.pow((x1 - x2), 2)
               + Math.pow((y1 - y2), 2));
         double side2 = Math.sqrt(Math.pow((x1 - x3), 2)
               + Math.pow((y1 - y3), 2));
         double side3 = Math.sqrt(Math.pow((x2 - x3), 2)
               + Math.pow((y2 - y3), 2));
         // computer math needed to find 3 sides, based off user input
         
         double s = (side1 + side2 + side3) / 2;
         // compute s,based off sides: 1-3
         
         double area = Math.sqrt(s * ((s - side1) * (s - side2) * (s - side3)));
         // computer area from s and sides 1-3
         
         System.out.printf("Area of the triangle is: %.2f", area);
         // output area
      }
}
