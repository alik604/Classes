public class LinearConversion{
public static void main(String[] args) {

		System.out.println("feet     meters");
		for (double feet = 1; feet <= 10; feet++) {
			if (feet == 10)
				System.out.printf("%.1f     %.3f\n", feet, footToMeter(feet));
			else
				System.out.printf("%.1f      %.3f\n", feet, footToMeter(feet));
			// System.out.println(meterToFoot(feet));
		}
		System.out.println("\n");
		System.out.println("meters    feet ");
		for (double meter = 20; meter <= 65; meter += 5) {
			System.out.printf("%.1f      %.3f\n", meter, meterToFoot(meter));
			// System.out.println(meterToFoot(meter));
		}

	}// end of main

	public static double footToMeter(double foot) {
		return foot * 0.305;
	}

	public static double meterToFoot(double meter) {
		return meter *= 3.2787;
	}
}