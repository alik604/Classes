
import java.util.Scanner;

/** @kali cpsc 1150
 * complete find longest and shortest
 */

public class ParseSentence{
public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String sentance = "";
		int userChoice;
		String temp;
		while (true) {
			System.out.println("1. Enter a new sentance");
			System.out.println("2. Display the sentance in uppercase");
			System.out.println("3. Count the number of words");
			System.out.println("4. Count the number of vowels");
			System.out.println("5. Find the longest word in the sentance");
			System.out.println("0. Exit");
			temp = scan.nextLine();
			userChoice = Integer.parseInt(temp);
			switch (userChoice) {
			case 1:
				System.out.println("please enter sentance:");
				sentance = scan.nextLine();
				break;
			case 2:
				System.out.println("Sentance is uppercase is:"
						+ toUpperCase(sentance));
				break;
			case 3:
				System.out.println("Number of words is: "
						+ countWords(sentance));
				break;
			case 4:
				System.out.println("Number of Vowels is: "
						+ countVowels(sentance));
				break;
			case 5:
				System.out.println("the longest word is: "
						+ findLongest(sentance));
				break;
			case 0:
				System.exit(0);
			default:
				System.out.println("try again");
			}
		} // end of while (true) loop
	}// main

	public static String toUpperCase(String sen) {
		int temp = 0;
		char ch;
		String senUpperCase = "";
		for (int i = 0; i < sen.length(); i++) {
			if (sen.charAt(i) >= 'a' && sen.charAt(i) <= 'z') {
				ch = sen.charAt(i);
				temp = (int) ch;
				temp -= 32;
				ch = (char) temp;
				senUpperCase += ch;
				// System.out.println("!!!!!-------no bug here :) -----!!!!!!!!!!!!!!");
			} else
				senUpperCase += sen.charAt(i);
		}
		return senUpperCase;
	}

	public static int countWords(String sen) {
		int number = 1;
		for (int i = 0; i < sen.length(); i++)
			if (sen.charAt(i) == ' ')
				number++;
		return number;
	}

	public static int countVowels(String sen) {
		int vowels = 0;
		for (int i = 0; i < sen.length(); i++)
			switch (sen.charAt(i)) {
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u':
				vowels++;
				break;
			}
		return vowels;
	}

	public static String findLongest(String sen) {
		String biggestWord = "";
		String currentWord = sen;
		int bIndex = 0;
		int eIndex = 0;

		for (int i = 0; i < sen.length(); i++) {
			eIndex = currentWord.indexOf(' ');
			if (eIndex == -1)
				return biggestWord;

			if (sen.substring(bIndex, eIndex).length() > biggestWord.length())
				biggestWord = sen.substring(bIndex, eIndex);

			currentWord = sen.substring(bIndex, eIndex);

			System.out.println(biggestWord);

		}

		/**
		 * String[] parts = sen.split(" "); for (int i = 0; i < parts.length;
		 * i++) { if (parts[i].length() > biggestWord.length()) biggestWord =
		 * parts[i]; }
		 */
		return biggestWord;

	}
}