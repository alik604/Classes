/*
 *Program Name:	PhoneKeyPads.java
 *Author:		Khizr ali pardhan
 *Date:		Feb 6th, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */

import java.util.Scanner;

public class PhoneKeyPads {
   //class
	public static void main(String[] args) {
     // main
		Scanner scan = new Scanner(System.in);
        // creat scanner object
		String input = "";
		do {
			System.out.printf("Enter a letter: ");
			input = scan.nextLine();// should have used the hint, and used
									// next(), that way i would not need the
									// loop
		} while (input.length() != 1);
          //get input
		input = input.toLowerCase();
          //convert input to lowercase
		char letter = input.charAt(0);
         //convert to char
		if ((int) letter >= 97 && (int) letter <= 122) {
			// System.out.println("its a letter!: " + letter);
		} else
			System.out.println(letter + " is an invalid input");

		switch (letter) {
		case 'a':
		case 'b':
		case 'c':
			System.out.println("The corresponding number is 2");
			break;

		case 'd':
		case 'e':
		case 'f':
			System.out.println("The corresponding number is 3");
			break;

		case 'h':
		case 'g':
		case 'i':
			System.out.println("The corresponding number is 4");
			break;

		case 'j':
		case 'k':
		case 'l':
			System.out.println("The corresponding number is 5");
			break;

		case 'm':
		case 'n':
		case 'o':
			System.out.println("The corresponding number is 6");
			break;

		case 'p':
		case 'q':
		case 'r':
		case 's':
			System.out.println("The corresponding number is 7");
			break;

		case 't':
		case 'u':
		case 'v':
			System.out.println("The corresponding number is 8");
			break;

		case 'w':
		case 'x':
		case 'y':
		case 'z':
			System.out.println("The corresponding number is 9");
			break;

		}
          //display crosponding letter 
	}
}
