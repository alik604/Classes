/*
 *Program Name:	DaysInMonth.java
 *Author:		Khizr ali pardhan
 *Date:		Feb 6th, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */

import java.util.Scanner;

public class DaysInMonth {
      //class
	public static void main(String[] args) {
		   //main
      Scanner scan = new Scanner(System.in);
            //scanner
		System.out.println("please enter month: ");
		int month = scan.nextInt();

		System.out.println("please enter year: ");
		int year = scan.nextInt();
		   //input
      int days = 0;
		boolean isLeapYear = ((year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0));
         //check for leapyear
		switch (month) {

		case 1:
			days = 31;
			break;
		case 2:
			days = 28; // had to do this due to weird error
			if (isLeapYear == true) {
				days = 29;
			}
			break;
		case 3:
			days = 31;
			break;
		case 4:
			days = 30;
			break;
		case 5:
			days = 31;
			break;
		case 6:
			days = 30;
			break;
		case 7:
			days = 31;
			break;
		case 8:
			days = 31;
			break;
		case 9:
			days = 30;
			break;
		case 10:
			days = 31;
			break;
		case 11:
			days = 30;
			break;
		case 12:
			days = 31;
			break;
		}
         //run switch statement
		System.out.println("days: " + days);
	         //output
      }
}
