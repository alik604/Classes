/*
 *Program Name:	KgToPound.java
 *Author:		Khizr ali pardhan
 *Date:		february 9th, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */

class KgToPound{
// main
	public static void main(String[] args) {
	
		// title
		System.out.println("kilograms        Pounds ");
		// "i" is for KG and as count, I prefer "i" for all counters variables
		int i = 1;
		double pounds;

		while (i < 20) {
			pounds = i * 2.2;
			// 1 kg is 2.2 pounds
			if (pounds < 7)
				System.out.printf(i + "%19.1f\n", pounds);
			else if (pounds > 7 && pounds < 20)
				System.out.printf(i + "%20.1f\n", pounds);
			else
				System.out.printf(i + "%19.1f\n", pounds);
			i += 2;
		}
		// while loop for unit conversions

	}
}




