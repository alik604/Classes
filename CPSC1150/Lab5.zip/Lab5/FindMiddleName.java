import java.util.Scanner;
/*
 *Program Name:	FindMiddleName.java
 *Author:		Khizr ali pardhan
 *Date:		february 9th, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */
class FindMiddleName{
   // main
	public static void main(String[] args) {

		// scanner obj
		Scanner scan = new Scanner(System.in);
		// get name from user
		System.out.println("enter name ");
		String name = scan.nextLine();
		// name = "khizr ali pardhan"; //for debugging
		// get index of secound name
		int startOfSecoundName = name.indexOf(" ");
		// get start of last name
		int startofLastName = name.lastIndexOf(" ");
		// isolate middle name
		String middleName = name.substring(startOfSecoundName, startofLastName);
		//output
      System.out.println("middle name is:" + middleName);

	}
}
   
   
   
   
