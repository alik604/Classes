import java.util.Scanner;
/*
 *Program Name:	CountNumbers.java
 *Author:		Khizr ali pardhan
 *Date:		february 9th, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */

class CountNumbers{
// main
	public static void main(String[] args) {

		// scanner obj
		Scanner scan = new Scanner(System.in);
		// create variables
		double input = 1;
		double sum = 0;
		int numberOfPos = 0;
		int numberOfNeg = 0;
		// create while loop
		while (input != 0) {
			System.out
					.println("please enter numbers to find average, number of evens and odds");
			input = scan.nextDouble();
			sum += input;
			if (input > 0)
				numberOfPos++;
			else if (input < 0)
				numberOfNeg++;
		}
		// calculate average
		double average = sum / (numberOfNeg + numberOfPos);
		// output
		System.out
				.printf("you entered %d positive numbers(s) and %d negitive number(s), and the average value is %.2f",
						numberOfPos, numberOfNeg, average);
	}
}