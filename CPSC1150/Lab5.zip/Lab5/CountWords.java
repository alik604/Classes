import java.util.Scanner;
/*
 *Program Name:	CountWords.java
 *Author:		Khizr ali pardhan
 *Date:		february 9th, 2017
 *Course:		CPSC 1150 - 2
 *Instructor:	mingwu chen
 */
class CountWords{
   // main
	public static void main(String[] args) {

		// scanner obj
		Scanner scan = new Scanner(System.in);
		// get sentance from user
		System.out.println("enter a sentance");
		String str = scan.nextLine();
		// str = "this is a sentance";
		int count = 1;
		if (str.length() < 1)// so, if no words, correct number will display
			count--;
		// for loop
		for (int i = 0; i < str.length() - 1; i++)
			// char at index for for loop
			if (str.charAt(i) == ' ')
				count++;
		// output
		System.out.println("number of words: "+count);
	}
}