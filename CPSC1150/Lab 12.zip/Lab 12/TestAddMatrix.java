import java.util.Scanner;
 
public class TestAddMatrix {
   public static void main(String[] args) {
//check if 2 matrixes are same lenght 
		int[][] arraya = new int[][] { { 1, 0, 0, 0, 0, 99, 1, 0, 0, 1 },
				{ 0, 0, 0, 0, 33, 0, 0, 0, 0, 0 },
				{ 0, 0, 0, 0, 2, 0, 0, 0, 0, 0 },
				{ 0, 0, 0, 0, 7, 0, 0, 0, 99, 0 },
				{ 0, 2, 0, 0, 5, 0, 0, 0, 0, 0 } };
		int[][] arrayb = new int[][] { { 1, 0, 0, 0, 0, 99, 1, 0, 0, 0 },
				{ 0, 0, 0, 0, 33, 0, 0, 0, 3, 0 },
				{ 0, 0, 0, 0, 2, 0, 0, 0, 0, 0 },
				{ 0, 0, 0, 0, 7, 0, 0, 0, 99, 0 },
				{ 0, 2, 0, 0, 5, 0, 0, 0, 0, 0 } };

		// for (int i = 0; i < array.length; i++) { }
		int[][] mySum = addMatrixes(arraya, arrayb);
		
		for (int i = 0; i < mySum.length; i++) {
			for (int j = 0; j < mySum[0].length; j++) {
				System.out.print(mySum[i][j] + " ");
			}
			System.out.println();
		}

	}// main

	public static int[][] addMatrixes(int[][] m1, int[][] m2) {

		// for (int i = 0; i < m1[0].length; i++)
		if (m1.length != m2.length || m1[0].length != m2[0].length) {
			System.out
					.println("the two matrices must have the same dimensions!");
			System.exit(1);
		}

		int sum[][] = new int[5][10];

		// int[][] dst = new int[m1.length][m1[0].length];

		for (int i = 0; i < m1.length; i++) {
			for (int j = 0; j < m1[0].length; j++) {
				// dst[i][j] = m1[i][j] + m2[i][j];
				sum[i][j] += m1[i][j] + m2[i][j];
			}
		}

		return sum;
	}
   }