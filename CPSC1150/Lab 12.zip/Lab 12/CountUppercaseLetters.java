import java.util.Scanner;
 
public class CountUppercaseLetters {
          public static void main(String[] args) {

		int sum = 0;
		String[] str = { "How", "is", "John", "doing", "today?", };
		for (int i = 0; i < args.length; i++) {
			for (int j = 0; j < args[i].length(); j++) {
				if (args[i].charAt(j) >= 'A' && args[i].charAt(j) <= 'Z')
					sum++;
			}
		}
		System.out.println(sum);
    }// main
}// class