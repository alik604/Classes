public class CheckerBoard {
	public static void main(String[] args) {
		int[][] matrix = new int[8][8];

		for (int i = 0; i < matrix.length; i++) {// row
			for (int j = 0; j < matrix[0].length; j++) {// col
				matrix[i][j] = (int) (Math.random() * 2);
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println();
		}
		
		
		
		
		
		
		System.out.println("**");
		// row 1
		boolean col0 = false;

		for (int col = 0; col < 7; col++) {
			for (int i = 0; i < matrix.length; i++) {// col
				if (matrix[i][col] == 0) {
					col0 = true;
				} else {
					col0 = false;
					break;
				}
			}
			if (col0)
				System.out.println("All 0�s on col " + col);
		}// row loop
	}
}// test1

